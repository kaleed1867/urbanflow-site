export const products = [
  {
    id: "shirt001",
    name: "UrbanFlow Tee",
    description: "Soft cotton tee with UrbanFlow logo",
    price: 29.99,
    sizes: ["S", "M", "L", "XL"],
    image: "/images/shirt001.png",
  },
  {
    id: "hoodie002",
    name: "UrbanFlow Hoodie",
    description: "Cozy fleece hoodie for cooler days",
    price: 49.99,
    sizes: ["M", "L", "XL"],
    image: "/images/hoodie002.png",
  },
];