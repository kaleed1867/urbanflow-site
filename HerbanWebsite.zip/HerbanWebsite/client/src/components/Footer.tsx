import { Leaf, Facebook, Instagram, Twitter, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function Footer() {
  return (
    <footer className="bg-[hsl(var(--primary-dark))] text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center mb-4">
              <Leaf className="text-white h-6 w-6 mr-2" />
              <span className="text-2xl font-semibold">Herban Flow</span>
            </div>
            <p className="text-white/80 mb-4">
              Natural solutions for modern living, promoting wellness through the
              power of herbs.
            </p>
            <div className="flex space-x-4">
              <a
                href="#"
                className="text-white hover:text-[hsl(var(--primary-light))] transition duration-200"
              >
                <Facebook size={20} />
              </a>
              <a
                href="#"
                className="text-white hover:text-[hsl(var(--primary-light))] transition duration-200"
              >
                <Instagram size={20} />
              </a>
              <a
                href="#"
                className="text-white hover:text-[hsl(var(--primary-light))] transition duration-200"
              >
                <Twitter size={20} />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <a
                  href="#about"
                  className="text-white/80 hover:text-white transition duration-200"
                >
                  About Us
                </a>
              </li>
              <li>
                <a
                  href="#products"
                  className="text-white/80 hover:text-white transition duration-200"
                >
                  Products
                </a>
              </li>
              <li>
                <a
                  href="#services"
                  className="text-white/80 hover:text-white transition duration-200"
                >
                  Services
                </a>
              </li>
              <li>
                <a
                  href="#testimonials"
                  className="text-white/80 hover:text-white transition duration-200"
                >
                  Testimonials
                </a>
              </li>
              <li>
                <a
                  href="#contact"
                  className="text-white/80 hover:text-white transition duration-200"
                >
                  Contact Us
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Customer Service</h3>
            <ul className="space-y-2">
              <li>
                <a
                  href="#"
                  className="text-white/80 hover:text-white transition duration-200"
                >
                  Shipping Policy
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-white/80 hover:text-white transition duration-200"
                >
                  Return Policy
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-white/80 hover:text-white transition duration-200"
                >
                  Privacy Policy
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-white/80 hover:text-white transition duration-200"
                >
                  Terms of Service
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-white/80 hover:text-white transition duration-200"
                >
                  FAQ
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Newsletter</h3>
            <p className="text-white/80 mb-4">
              Subscribe to our newsletter for updates on new products,
              promotions, and herbal wellness tips.
            </p>
            <form className="flex">
              <Input
                type="email"
                placeholder="Your email"
                className="rounded-r-none bg-white text-[hsl(var(--neutral-darkest))]"
              />
              <Button 
                type="submit"
                className="bg-[hsl(var(--primary))] hover:bg-[hsl(var(--primary-light))] text-white rounded-l-none"
              >
                <Send size={18} />
              </Button>
            </form>
          </div>
        </div>

        <div className="border-t border-white/20 mt-8 pt-8 text-center text-white/60">
          <p>&copy; {new Date().getFullYear()} Herban Flow. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
