import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Leaf } from "lucide-react";

export default function Navbar() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-sm shadow-sm">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <Link href="/" className="flex items-center">
            <Leaf className="text-[hsl(var(--primary-dark))] h-6 w-6 mr-2" />
            <span className="text-2xl font-semibold text-[hsl(var(--primary-dark))]">
              Herban Flow
            </span>
          </Link>
        </div>

        {/* Mobile menu button */}
        <button
          onClick={toggleMobileMenu}
          className="md:hidden text-neutral-darkest focus:outline-none"
          aria-label={isMobileMenuOpen ? "Close menu" : "Open menu"}
        >
          {isMobileMenuOpen ? (
            <span className="material-icons">close</span>
          ) : (
            <span className="material-icons">menu</span>
          )}
        </button>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <a
            href="#about"
            className="text-[hsl(var(--neutral-dark))] hover:text-[hsl(var(--primary-dark))] transition duration-200"
          >
            About
          </a>
          <a
            href="#products"
            className="text-[hsl(var(--neutral-dark))] hover:text-[hsl(var(--primary-dark))] transition duration-200"
          >
            Products
          </a>
          <a
            href="#services"
            className="text-[hsl(var(--neutral-dark))] hover:text-[hsl(var(--primary-dark))] transition duration-200"
          >
            Services
          </a>
          <a
            href="#testimonials"
            className="text-[hsl(var(--neutral-dark))] hover:text-[hsl(var(--primary-dark))] transition duration-200"
          >
            Testimonials
          </a>
          <Button
            asChild
            className="bg-[hsl(var(--primary-dark))] hover:bg-[hsl(var(--primary))] text-white"
          >
            <a href="#contact">Contact Us</a>
          </Button>
        </nav>
      </div>

      {/* Mobile Navigation */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-neutral pb-4">
          <nav className="container mx-auto px-4 flex flex-col space-y-3 pt-3">
            <a
              href="#about"
              className="text-[hsl(var(--neutral-dark))] hover:text-[hsl(var(--primary-dark))] transition duration-200 py-2"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              About
            </a>
            <a
              href="#products"
              className="text-[hsl(var(--neutral-dark))] hover:text-[hsl(var(--primary-dark))] transition duration-200 py-2"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Products
            </a>
            <a
              href="#services"
              className="text-[hsl(var(--neutral-dark))] hover:text-[hsl(var(--primary-dark))] transition duration-200 py-2"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Services
            </a>
            <a
              href="#testimonials"
              className="text-[hsl(var(--neutral-dark))] hover:text-[hsl(var(--primary-dark))] transition duration-200 py-2"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Testimonials
            </a>
            <Button
              asChild
              className="bg-[hsl(var(--primary-dark))] hover:bg-[hsl(var(--primary))] text-white w-full"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              <a href="#contact">Contact Us</a>
            </Button>
          </nav>
        </div>
      )}
    </header>
  );
}
