import { useState } from "react";

import { products } from "@/lib/product";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function Home() {}

  const [selectedProduct, setSelectedProduct] = useState(null);
  const [open, setOpen] = useState(false);

  const handleViewDetails = (product: any) => {
    setSelectedProduct(product);
    setOpen(true);
  };

  return (
    <>
      {/* Hero Section */}
      <section className="hero-pattern py-16 md:py-24 text-center bg-[hsl(var(--neutral-light))]">
        <div className="container mx-auto px-4">
          <h1 className="text-5xl font-bold mb-4 text-[hsl(var(--primary-dark))]">
            Welcome to Urbanflow
          </h1>
          <p className="text-lg text-[hsl(var(--neutral-dark))] mb-6">
            Premium lifestyle gear, natural living, and affiliate essentials.
          </p>
          <Button size="lg" className="bg-green-600 hover:bg-green-700 text-white">
            Shop Now
          </Button>
        </div>
      </section>

      {/* Products Section */}
      <section id="products" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-[hsl(var(--primary-dark))]">
              Featured Products
            </h2>
            <p className="text-[hsl(var(--neutral-dark))] max-w-xl mx-auto mt-4">
              Curated affiliate products selected just for you.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {products.map((product) => (
              <Card
                key={product.id}
                className="rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all"
              >
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-64 object-cover"
                />
                <CardContent className="p-6 flex flex-col h-full justify-between">
                  <div>
                    <h3 className="text-2xl font-bold text-gray-800 mb-2">{product.name}</h3>
                    <p className="text-gray-600">{product.description}</p>
                  </div>
                  <div className="flex justify-between items-center mt-4">
                    <span className="text-green-600 font-bold text-lg">
                      ${product.price.toFixed(2)}
                    </span>
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleViewDetails(product)}
                      >
                        View Details
                      </Button>
                      <Button
                        size="sm"
                        className="bg-green-600 hover:bg-green-700 text-white"
                        asChild
                      >
                        <a href="https://example.com" target="_blank" rel="noopener noreferrer">
                          Buy Now
                        </a>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-16">
            <Button
              variant="outline"
              className="border-green-600 text-green-600 hover:bg-green-600 hover:text-white font-bold"
              size="lg"
            >
              View All Products
            </Button>
          </div>
        </div>
      </section>

      {/* Product Modal (View Details Pop-up) */}
      <Dialog open={open} onOpenChange={setOpen}>
        {selectedProduct && (
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{selectedProduct.name}</DialogTitle>
            </DialogHeader>
            <div className="flex flex-col sm:flex-row gap-6 mt-4">
              <img
                src={selectedProduct.image}
                alt={selectedProduct.name}
                className="w-full sm:w-1/2 object-cover rounded-lg"
              />
              <div className="flex-1 flex flex-col justify-between">
                <div>
                  <p className="text-gray-700 mb-4">{selectedProduct.description}</p>
                  <p className="font-semibold text-lg mb-2">
                    Sizes Available: {selectedProduct.sizes.join(", ")}
                  </p>
                  <p className="text-green-600 font-bold text-2xl">
                    ${selectedProduct.price.toFixed(2)}
                  </p>
                </div>
                <Button
                  className="bg-green-600 hover:bg-green-700 text-white mt-6"
                  asChild
                >
                  <a href="https://example.com" target="_blank" rel="noopener noreferrer">
                    Buy Now
                  </a>
                </Button>
              </div>
            </div>
    </DialogContent>
  </Dialog>
</>
);
}