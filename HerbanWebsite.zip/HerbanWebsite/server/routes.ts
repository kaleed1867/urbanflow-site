import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { products } from "../shared/products";
export async function registerRoutes(app: Express): Promise<Server> {
  // API endpoint to get basic business information
  app.get("/api/business-info", (_req, res) => {
    const businessInfo = {
      name: "Herban Flow",
      description: "Natural solutions for modern living, promoting wellness through the power of herbs.",
      contact: {
        address: "123 Nature Way, Green Valley, CA 90210",
        phone: "(555) 123-4567",
        email: "info@herbanflow.com",
        hours: {
          monFri: "9AM - 6PM",
          sat: "10AM - 4PM",
          sun: "Closed"
        }
      },
      social: {
        facebook: "https://facebook.com/herbanflow",
        instagram: "https://instagram.com/herbanflow",
        twitter: "https://twitter.com/herbanflow"
      }
    };
    
    res.json(businessInfo);
  });

  // API endpoint for submitting contact form
  app.post("/api/contact", (req, res) => {
    const { name, email, subject, message } = req.body;
    
    // Validate required fields
    if (!name || !email || !message) {
      return res.status(400).json({ 
        success: false,
        message: "Please provide name, email, and message" 
      });
    }
    
    // In a real implementation, you would store the contact form data
    // or send an email notification
    
    // For now, just return success response
    res.json({ 
      success: true,
      message: "Thank you for your message. We'll get back to you soon!" 
    });
  });

  const httpServer = createServer(app);
  // API endpoint to get all products
  app.get("/api/products", (_req, res) => {
    res.json(products);
  });
  return httpServer;
}
